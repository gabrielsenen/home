const express = require('express');
const route = express.Router();
const controller = require('./src/controler/controler')
const controller2 = require('./src/controler/controler2')

route.get('/', controller.passo1);
route.get('/index2.ejs', controller2.passo2);

module.exports = route