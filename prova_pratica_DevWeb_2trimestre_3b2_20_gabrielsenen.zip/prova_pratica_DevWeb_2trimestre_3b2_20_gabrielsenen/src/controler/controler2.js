exports.passo2 = (req, res) =>{
    res.render(`index2`);
};
