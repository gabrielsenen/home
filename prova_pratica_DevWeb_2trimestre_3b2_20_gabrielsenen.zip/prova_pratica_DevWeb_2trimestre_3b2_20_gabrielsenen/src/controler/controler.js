exports.passo1 = (req, res) =>{
    res.render(`index`);
};